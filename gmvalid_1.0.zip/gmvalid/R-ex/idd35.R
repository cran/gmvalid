### Name: idd35
### Title: Type 1 Diabetes susceptibility loci Idd3 and Idd5
### Aliases: idd35
### Keywords: datasets

### ** Examples

  data(idd35)
  table(idd35)



