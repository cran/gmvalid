### Name: wam
### Title: Women and Mathematics
### Aliases: wam
### Keywords: datasets

### ** Examples

  data(wam)
  gm.analysis(wam, program="coco")



