### Name: gm.generate
### Title: Random data frames of binary variables with given marginals
### Aliases: gm.generate
### Keywords: datagen distribution

### ** Examples

gm.generate(10,c(.5,.2,.2))
gm.generate(15,c(.5,.5,.5,.5,.5,.5))



